package gui;

import models.*;
import utils.FileHandler;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;
import java.awt.*;

public class AdminGUI extends JFrame {
    private JTabbedPane tabbedPane;
    private DefaultTableModel hotelsModel, packagesModel, destinationsModel, bookingsModel, guidesModel, transportsModel;

    public AdminGUI() {
        setTitle("Admin Portal - System Management");
        setSize(1200, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setupUI();
    }

    private void setupUI() {
        setLayout(new BorderLayout());

        // ── HEADER — matches TourGuideGUI exactly ──────────────────────────
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(0, 51, 102));
        headerPanel.setPreferredSize(new Dimension(1200, 70));
        headerPanel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("ADMIN CONTROL PANEL");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        headerPanel.add(titleLabel, BorderLayout.WEST);

        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        infoPanel.setOpaque(false);

        JLabel userLabel = new JLabel("Administrator");
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        infoPanel.add(userLabel);

        // LOGOUT — same style as TourGuideGUI: dark-red bg, WHITE text
        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setBackground(new Color(180, 0, 0));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 12));
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> logout());
        infoPanel.add(logoutBtn);

        headerPanel.add(infoPanel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // ── TABS ───────────────────────────────────────────────────────────
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.setBackground(Color.WHITE);

        tabbedPane.addTab("HOTELS",       createHotelsPanel());
        tabbedPane.addTab("PACKAGES",     createPackagesPanel());
        tabbedPane.addTab("DESTINATIONS", createDestinationsPanel());
        tabbedPane.addTab("BOOKINGS",     createBookingsPanel());
        tabbedPane.addTab("TOUR GUIDES",  createGuidesPanel());
        tabbedPane.addTab("TRANSPORT",    createTransportsPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    // ── SHARED HELPERS matching TourGuideGUI style ─────────────────────────

    /** Table styled like TourGuideGUI tables */
    private JTable makeTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.getTableHeader().setBackground(new Color(220, 220, 220));
        table.getTableHeader().setForeground(new Color(0, 51, 102));
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(0, 102, 204));
        table.setSelectionForeground(Color.WHITE);
        return table;
    }

    /** Titled form border matching TourGuideGUI colours */
    private JPanel makeFormPanel(String title) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(150, 180, 210), 2),
            title,
            TitledBorder.DEFAULT_JUSTIFICATION,
            TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 12),
            new Color(0, 51, 102)
        ));
        return p;
    }

    /** Green action button — WHITE foreground */
    private JButton greenBtn(String text, Dimension size) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(0, 120, 0));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        btn.setPreferredSize(size);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(0, 150, 0)); }
            public void mouseExited (java.awt.event.MouseEvent e) { btn.setBackground(new Color(0, 120, 0)); }
        });
        return btn;
    }

    /** Red action button — WHITE foreground */
    private JButton redBtn(String text, Dimension size) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(180, 0, 0));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        btn.setPreferredSize(size);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(210, 0, 0)); }
            public void mouseExited (java.awt.event.MouseEvent e) { btn.setBackground(new Color(180, 0, 0)); }
        });
        return btn;
    }

    /** Orange toggle button — WHITE foreground */
    private JButton orangeBtn(String text, Dimension size) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(160, 85, 0));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        btn.setPreferredSize(size);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(195, 110, 0)); }
            public void mouseExited (java.awt.event.MouseEvent e) { btn.setBackground(new Color(160,  85, 0)); }
        });
        return btn;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HOTELS
    // ══════════════════════════════════════════════════════════════════════════
    private JPanel createHotelsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);

        JLabel title = new JLabel("Manage Hotels");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Hotel ID", "Name", "Location", "Stars", "Price/Night", "Rooms"};
        hotelsModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = makeTable(hotelsModel);
        refreshHotels();
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel formPanel = makeFormPanel("Add New Hotel");

        JTextField idField    = new JTextField(6);
        JTextField nameField  = new JTextField(10);
        JTextField locField   = new JTextField(8);
        JSpinner   starsSpin  = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1));
        JTextField priceField = new JTextField(6);
        JSpinner   roomsSpin  = new JSpinner(new SpinnerNumberModel(10, 1, 500, 1));

        formPanel.add(new JLabel("ID:"));       formPanel.add(idField);
        formPanel.add(new JLabel("Name:"));     formPanel.add(nameField);
        formPanel.add(new JLabel("Location:")); formPanel.add(locField);
        formPanel.add(new JLabel("Stars:"));    formPanel.add(starsSpin);
        formPanel.add(new JLabel("Price:"));    formPanel.add(priceField);
        formPanel.add(new JLabel("Rooms:"));    formPanel.add(roomsSpin);

        JButton addBtn = greenBtn("ADD HOTEL",       new Dimension(120, 35));
        JButton delBtn = redBtn  ("DELETE SELECTED", new Dimension(130, 35));

        addBtn.addActionListener(e -> {
            try {
                Hotel hotel = new Hotel(idField.getText(), nameField.getText(), locField.getText(),
                    (int) starsSpin.getValue(), Double.parseDouble(priceField.getText()),
                    (int) roomsSpin.getValue());
                java.util.ArrayList<Hotel> hotels = FileHandler.loadHotels();
                hotels.add(hotel);
                FileHandler.saveHotels(hotels);
                refreshHotels();
                JOptionPane.showMessageDialog(this, "Hotel added!");
                idField.setText(""); nameField.setText(""); locField.setText(""); priceField.setText("");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid data!"); }
        });

        delBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) hotelsModel.getValueAt(row, 0);
                java.util.ArrayList<Hotel> hotels = FileHandler.loadHotels();
                hotels.removeIf(h -> h.getHotelID().equals(id));
                FileHandler.saveHotels(hotels);
                refreshHotels();
                JOptionPane.showMessageDialog(this, "Hotel deleted!");
            } else { JOptionPane.showMessageDialog(this, "Select a hotel to delete!"); }
        });

        formPanel.add(addBtn);
        formPanel.add(delBtn);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshHotels() {
        hotelsModel.setRowCount(0);
        for (Hotel h : FileHandler.loadHotels())
            hotelsModel.addRow(new String[]{h.getHotelID(), h.getName(), h.getLocation(),
                h.getStarRating() + "★", "$" + h.getPricePerNight(), String.valueOf(h.getAvailableRooms())});
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PACKAGES
    // ══════════════════════════════════════════════════════════════════════════
    private JPanel createPackagesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);

        JLabel title = new JLabel("Manage Packages");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Package ID", "Title", "Description", "Price", "Duration"};
        packagesModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = makeTable(packagesModel);
        refreshPackages();
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel formPanel = makeFormPanel("Add New Package");

        JTextField idField    = new JTextField(6);
        JTextField titleField = new JTextField(10);
        JTextField descField  = new JTextField(15);
        JTextField priceField = new JTextField(6);
        JSpinner   durSpin    = new JSpinner(new SpinnerNumberModel(5, 1, 30, 1));

        formPanel.add(new JLabel("ID:"));    formPanel.add(idField);
        formPanel.add(new JLabel("Title:")); formPanel.add(titleField);
        formPanel.add(new JLabel("Desc:"));  formPanel.add(descField);
        formPanel.add(new JLabel("Price:")); formPanel.add(priceField);
        formPanel.add(new JLabel("Days:"));  formPanel.add(durSpin);

        JButton addBtn = greenBtn("ADD PACKAGE",     new Dimension(120, 35));
        JButton delBtn = redBtn  ("DELETE SELECTED", new Dimension(130, 35));

        addBtn.addActionListener(e -> {
            try {
                TourPackage pkg = new TourPackage(idField.getText(), titleField.getText(), descField.getText(),
                    Double.parseDouble(priceField.getText()), (int) durSpin.getValue());
                java.util.ArrayList<TourPackage> packages = FileHandler.loadPackages();
                packages.add(pkg);
                FileHandler.savePackages(packages);
                refreshPackages();
                JOptionPane.showMessageDialog(this, "Package added!");
                idField.setText(""); titleField.setText(""); descField.setText(""); priceField.setText("");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid data!"); }
        });

        delBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) packagesModel.getValueAt(row, 0);
                java.util.ArrayList<TourPackage> packages = FileHandler.loadPackages();
                packages.removeIf(p -> p.getPackageID().equals(id));
                FileHandler.savePackages(packages);
                refreshPackages();
                JOptionPane.showMessageDialog(this, "Package deleted!");
            } else { JOptionPane.showMessageDialog(this, "Select a package to delete!"); }
        });

        formPanel.add(addBtn);
        formPanel.add(delBtn);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshPackages() {
        packagesModel.setRowCount(0);
        for (TourPackage p : FileHandler.loadPackages())
            packagesModel.addRow(new String[]{p.getPackageID(), p.getTitle(), p.getDescription(),
                "$" + p.getPrice(), p.getDuration() + " days"});
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DESTINATIONS
    // ══════════════════════════════════════════════════════════════════════════
    private JPanel createDestinationsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);

        JLabel title = new JLabel("Manage Destinations");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"ID", "Name", "Country", "Description", "Rating"};
        destinationsModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = makeTable(destinationsModel);
        refreshDestinations();
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel formPanel = makeFormPanel("Add New Destination");

        JTextField idField      = new JTextField(6);
        JTextField nameField    = new JTextField(10);
        JTextField countryField = new JTextField(8);
        JTextField descField    = new JTextField(15);
        JTextField ratingField  = new JTextField(4);

        formPanel.add(new JLabel("ID:"));      formPanel.add(idField);
        formPanel.add(new JLabel("Name:"));    formPanel.add(nameField);
        formPanel.add(new JLabel("Country:")); formPanel.add(countryField);
        formPanel.add(new JLabel("Desc:"));    formPanel.add(descField);
        formPanel.add(new JLabel("Rating:"));  formPanel.add(ratingField);

        JButton addBtn = greenBtn("ADD DESTINATION", new Dimension(140, 35));
        JButton delBtn = redBtn  ("DELETE SELECTED", new Dimension(130, 35));

        addBtn.addActionListener(e -> {
            try {
                Destination dest = new Destination(idField.getText(), nameField.getText(), countryField.getText(),
                    descField.getText(), Double.parseDouble(ratingField.getText()));
                java.util.ArrayList<Destination> destinations = FileHandler.loadDestinations();
                destinations.add(dest);
                FileHandler.saveDestinations(destinations);
                refreshDestinations();
                JOptionPane.showMessageDialog(this, "Destination added!");
                idField.setText(""); nameField.setText(""); countryField.setText(""); descField.setText(""); ratingField.setText("");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid data!"); }
        });

        delBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) destinationsModel.getValueAt(row, 0);
                java.util.ArrayList<Destination> destinations = FileHandler.loadDestinations();
                destinations.removeIf(d -> d.getDestinationID().equals(id));
                FileHandler.saveDestinations(destinations);
                refreshDestinations();
                JOptionPane.showMessageDialog(this, "Destination deleted!");
            } else { JOptionPane.showMessageDialog(this, "Select a destination to delete!"); }
        });

        formPanel.add(addBtn);
        formPanel.add(delBtn);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshDestinations() {
        destinationsModel.setRowCount(0);
        for (Destination d : FileHandler.loadDestinations())
            destinationsModel.addRow(new String[]{d.getDestinationID(), d.getDestinationName(),
                d.getCountry(), d.getDescription(), d.getRating() + "★"});
    }

    // ══════════════════════════════════════════════════════════════════════════
    // BOOKINGS
    // ══════════════════════════════════════════════════════════════════════════
    private JPanel createBookingsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);

        JLabel title = new JLabel("Manage Bookings");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Booking ID", "Tourist", "Package", "Destination", "Price", "Status", "Date"};
        bookingsModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = makeTable(bookingsModel);
        refreshBookings();
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        btnPanel.setBackground(Color.WHITE);

        JButton approveBtn = greenBtn("APPROVE SELECTED", new Dimension(150, 40));
        JButton rejectBtn  = redBtn  ("REJECT SELECTED",  new Dimension(150, 40));

        approveBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) bookingsModel.getValueAt(row, 0);
                java.util.ArrayList<Booking> bookings = FileHandler.loadBookings();
                for (Booking b : bookings)
                    if (b.getBookingId().equals(id)) { b.setStatus("Confirmed"); break; }
                FileHandler.saveBookings(bookings);
                refreshBookings();
                JOptionPane.showMessageDialog(this, "Booking approved!");
            } else { JOptionPane.showMessageDialog(this, "Select a booking to approve!"); }
        });

        rejectBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) bookingsModel.getValueAt(row, 0);
                java.util.ArrayList<Booking> bookings = FileHandler.loadBookings();
                bookings.removeIf(b -> b.getBookingId().equals(id));
                FileHandler.saveBookings(bookings);
                refreshBookings();
                JOptionPane.showMessageDialog(this, "Booking rejected and removed!");
            } else { JOptionPane.showMessageDialog(this, "Select a booking to reject!"); }
        });

        btnPanel.add(approveBtn);
        btnPanel.add(rejectBtn);
        panel.add(btnPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshBookings() {
        bookingsModel.setRowCount(0);
        for (Booking b : FileHandler.loadBookings())
            bookingsModel.addRow(new String[]{b.getBookingId(), b.getTouristName(), b.getPackageTitle(),
                b.getDestinationName(), "$" + String.format("%.2f", b.getTotalPrice()),
                b.getStatus(), b.getBookingDate()});
    }

    // ══════════════════════════════════════════════════════════════════════════
    // TOUR GUIDES
    // ══════════════════════════════════════════════════════════════════════════
    private JPanel createGuidesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);   // was Color.GRAY

        JLabel title = new JLabel("Manage Tour Guides");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Guide ID", "Name", "Email", "Language", "Expertise", "Available"};
        guidesModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = makeTable(guidesModel);
        refreshGuides();
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel formPanel = makeFormPanel("Add New Tour Guide");

        JTextField     idField     = new JTextField(6);
        JTextField     nameField   = new JTextField(8);
        JTextField     emailField  = new JTextField(10);
        JTextField     langField   = new JTextField(6);
        JTextField     expertField = new JTextField(8);
        JPasswordField passField   = new JPasswordField(6);

        formPanel.add(new JLabel("ID:"));      formPanel.add(idField);
        formPanel.add(new JLabel("Name:"));    formPanel.add(nameField);
        formPanel.add(new JLabel("Email:"));   formPanel.add(emailField);
        formPanel.add(new JLabel("Lang:"));    formPanel.add(langField);
        formPanel.add(new JLabel("Expert:"));  formPanel.add(expertField);
        formPanel.add(new JLabel("Pass:"));    formPanel.add(passField);

        // was Color.RAY — fixed to WHITE via helper
        JButton addBtn = greenBtn("ADD GUIDE", new Dimension(120, 35));

        addBtn.addActionListener(e -> {
            try {
                TourGuide guide = new TourGuide(idField.getText(), nameField.getText(), emailField.getText(),
                    new String(passField.getPassword()), idField.getText(), langField.getText(), expertField.getText());
                java.util.ArrayList<TourGuide> guides = FileHandler.loadGuides();
                guides.add(guide);
                FileHandler.saveGuides(guides);
                refreshGuides();
                JOptionPane.showMessageDialog(this, "Guide added!");
                idField.setText(""); nameField.setText(""); emailField.setText("");
                langField.setText(""); expertField.setText(""); passField.setText("");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid data!"); }
        });

        formPanel.add(addBtn);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshGuides() {
        guidesModel.setRowCount(0);
        for (TourGuide g : FileHandler.loadGuides())
            guidesModel.addRow(new String[]{g.getGuideID(), g.getName(), g.getEmail(),
                g.getLanguage(), g.getExpertise(), g.isAvailable() ? "Yes" : "No"});
    }

    // ══════════════════════════════════════════════════════════════════════════
    // TRANSPORT
    // ══════════════════════════════════════════════════════════════════════════
    private JPanel createTransportsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);   // was Color.GRAY

        JLabel title = new JLabel("Manage Transport");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Transport ID", "Type", "Vehicle No", "Route", "Capacity", "Price/km", "Available", "Amenities"};
        transportsModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = makeTable(transportsModel);
        refreshTransports();
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(150, 180, 210), 2),
            "Add New Transport",
            TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION,
            new Font("Arial", Font.BOLD, 12), new Color(0, 51, 102)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField        idField       = new JTextField(6);
        JComboBox<String> typeCombo     = new JComboBox<>(new String[]{"AC Bus","Non-AC Bus","Mini Van","Luxury Car","Jeep","Boat","Train"});
        JTextField        vehicleField  = new JTextField(8);
        JTextField        fromField     = new JTextField(8);
        JTextField        toField       = new JTextField(8);
        JSpinner          capSpin       = new JSpinner(new SpinnerNumberModel(20, 2, 60, 1));
        JTextField        priceField    = new JTextField(6);
        JComboBox<String> amenitiesCombo= new JComboBox<>(new String[]{"Basic","AC","WiFi","Luxury","Premium"});
        JCheckBox         availCheck    = new JCheckBox("Available", true);
        availCheck.setBackground(Color.WHITE);

        int r = 0;
        gbc.gridx=0; gbc.gridy=r; formPanel.add(new JLabel("ID:"), gbc);
        gbc.gridx=1; formPanel.add(idField, gbc);
        gbc.gridx=2; formPanel.add(new JLabel("Type:"), gbc);
        gbc.gridx=3; formPanel.add(typeCombo, gbc);

        r++;
        gbc.gridx=0; gbc.gridy=r; formPanel.add(new JLabel("Vehicle No:"), gbc);
        gbc.gridx=1; formPanel.add(vehicleField, gbc);
        gbc.gridx=2; formPanel.add(new JLabel("From:"), gbc);
        gbc.gridx=3; formPanel.add(fromField, gbc);

        r++;
        gbc.gridx=0; gbc.gridy=r; formPanel.add(new JLabel("To:"), gbc);
        gbc.gridx=1; formPanel.add(toField, gbc);
        gbc.gridx=2; formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx=3; formPanel.add(capSpin, gbc);

        r++;
        gbc.gridx=0; gbc.gridy=r; formPanel.add(new JLabel("Price/km ($):"), gbc);
        gbc.gridx=1; formPanel.add(priceField, gbc);
        gbc.gridx=2; formPanel.add(new JLabel("Amenities:"), gbc);
        gbc.gridx=3; formPanel.add(amenitiesCombo, gbc);

        r++;
        gbc.gridx=0; gbc.gridy=r; formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx=1; formPanel.add(availCheck, gbc);

        JButton addBtn    = greenBtn ("ADD TRANSPORT",    new Dimension(130, 35));
        JButton deleteBtn = redBtn   ("DELETE SELECTED",  new Dimension(130, 35));
        JButton toggleBtn = orangeBtn("TOGGLE AVAIL.",    new Dimension(130, 35));

        addBtn.addActionListener(e -> {
            try {
                Transport transport = new Transport(
                    idField.getText(), (String) typeCombo.getSelectedItem(),
                    (int) capSpin.getValue(), fromField.getText(), toField.getText(),
                    Double.parseDouble(priceField.getText()), vehicleField.getText(),
                    (String) amenitiesCombo.getSelectedItem());
                transport.setAvailable(availCheck.isSelected());
                FileHandler.addTransport(transport);
                refreshTransports();
                JOptionPane.showMessageDialog(this, "Transport added!");
                idField.setText(""); vehicleField.setText(""); fromField.setText(""); toField.setText(""); priceField.setText("");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid data! " + ex.getMessage()); }
        });

        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) transportsModel.getValueAt(row, 0);
                FileHandler.deleteTransport(id);
                refreshTransports();
                JOptionPane.showMessageDialog(this, "Transport deleted!");
            } else { JOptionPane.showMessageDialog(this, "Select a transport to delete!"); }
        });

        toggleBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String id = (String) transportsModel.getValueAt(row, 0);
                Transport t = FileHandler.findTransportById(id);
                if (t != null) {
                    t.setAvailable(!t.isAvailable());
                    FileHandler.updateTransport(t);
                    refreshTransports();
                    JOptionPane.showMessageDialog(this, "Availability toggled!");
                }
            } else { JOptionPane.showMessageDialog(this, "Select a transport to toggle!"); }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        buttonPanel.setOpaque(false);
        buttonPanel.add(addBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(toggleBtn);

        r++;
        gbc.gridx=0; gbc.gridy=r; gbc.gridwidth=4;
        formPanel.add(buttonPanel, gbc);

        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshTransports() {
        transportsModel.setRowCount(0);
        for (Transport t : FileHandler.loadTransports())
            transportsModel.addRow(new String[]{
                t.getTransportID(), t.getTransportType(), t.getVehicleNumber(),
                t.getRouteFrom() + " → " + t.getRouteTo(), String.valueOf(t.getCapacity()),
                "$" + String.format("%.2f", t.getPricePerKm()),
                t.isAvailable() ? "Yes" : "No", t.getAmenities()
            });
    }

    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}