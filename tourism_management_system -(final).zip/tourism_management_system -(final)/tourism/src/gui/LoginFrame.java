package gui;

import auth.AuthManager;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JComboBox<String> roleCombo;
    private JTextField userIdField;
    private JPasswordField passwordField;
    
    public LoginFrame() {
        setTitle("Tourism Management System - Login");
        setSize(450, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(0, 51, 102)); // Darker blue background
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JLabel titleLabel = new JLabel("Tourism Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0;
        mainPanel.add(titleLabel, gbc);
        
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.WHITE);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150), 1),
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));
        
        GridBagConstraints lgbc = new GridBagConstraints();
        lgbc.insets = new Insets(10, 10, 10, 10);
        lgbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Role
        lgbc.gridx = 0; lgbc.gridy = 0;
        JLabel roleLabel = new JLabel("Select Role:");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 13));
        loginPanel.add(roleLabel, lgbc);
        
        roleCombo = new JComboBox<>(new String[]{"Tourist", "Admin", "Tour Guide"});
        roleCombo.setFont(new Font("Arial", Font.PLAIN, 13));
        roleCombo.setBackground(Color.WHITE);
        lgbc.gridx = 1;
        loginPanel.add(roleCombo, lgbc);
        
        // User ID
        lgbc.gridx = 0; lgbc.gridy = 1;
        JLabel userLabel = new JLabel("User ID:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 13));
        loginPanel.add(userLabel, lgbc);
        
        userIdField = new JTextField(15);
        userIdField.setFont(new Font("Arial", Font.PLAIN, 13));
        userIdField.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180)));
        lgbc.gridx = 1;
        loginPanel.add(userIdField, lgbc);
        
        // Password
        lgbc.gridx = 0; lgbc.gridy = 2;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.BOLD, 13));
        loginPanel.add(passLabel, lgbc);
        
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 13));
        passwordField.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180)));
        lgbc.gridx = 1;
        loginPanel.add(passwordField, lgbc);
        
        // Button Panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setOpaque(false);
        
        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(0, 102, 204)); // Dark blue
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 14));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorderPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.setPreferredSize(new Dimension(100, 35));
        loginBtn.addActionListener(e -> login());
        
        JButton clearBtn = new JButton("CLEAR");
        clearBtn.setBackground(new Color(153, 153, 153)); // Gray
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFont(new Font("Arial", Font.BOLD, 14));
        clearBtn.setFocusPainted(false);
        clearBtn.setBorderPainted(false);
        clearBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        clearBtn.setPreferredSize(new Dimension(100, 35));
        clearBtn.addActionListener(e -> clearFields());
        
        btnPanel.add(loginBtn);
        btnPanel.add(clearBtn);
        
        lgbc.gridx = 0; lgbc.gridy = 3;
        lgbc.gridwidth = 2;
        loginPanel.add(btnPanel, lgbc);
        
        gbc.gridy = 1;
        mainPanel.add(loginPanel, gbc);
        
        add(mainPanel);
    }
    
    private void login() {
        String role = ((String) roleCombo.getSelectedItem()).toLowerCase();
        String userId = userIdField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (userId.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter User ID and Password!");
            return;
        }
        
        AuthManager auth = AuthManager.getInstance();
        String authenticatedId = auth.authenticate(userId, password, role);
        
        if (authenticatedId != null) {
            dispose();
            if (role.equals("tourist")) {
                new TouristGUI(authenticatedId).setVisible(true);
            } else if (role.equals("admin")) {
                new AdminGUI().setVisible(true);
            } else if (role.equals("tour guide")) {
                new TourGuideGUI(authenticatedId).setVisible(true);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid User ID or Password!");
        }
    }
    
    private void clearFields() {
        userIdField.setText("");
        passwordField.setText("");
        roleCombo.setSelectedIndex(0);
    }
}