package gui;

import models.*;
import utils.FileHandler;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class TouristGUI extends JFrame {
    private String touristId;
    private Tourist currentTourist;
    private JPanel mainContentPanel;
    private CardLayout cardLayout;
    private DefaultTableModel bookingsModel;
    
    public TouristGUI(String touristId) {
        this.touristId = touristId;
        this.currentTourist = FileHandler.findTouristById(touristId);
        
        setTitle("Tourist Portal - Welcome " + currentTourist.getName());
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initializeUI();
    }
    
    private void initializeUI() {
        setLayout(new BorderLayout());
        
        // Top Header
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Left Sidebar
        JPanel sidebarPanel = createSidebarPanel();
        add(sidebarPanel, BorderLayout.WEST);
        
        // Main Content Area with CardLayout
        mainContentPanel = new JPanel();
        cardLayout = new CardLayout();
        mainContentPanel.setLayout(cardLayout);
        
        mainContentPanel.add(createDashboardPanel(), "DASHBOARD");
        mainContentPanel.add(createBookTourPanel(), "BOOK_TOUR");
        mainContentPanel.add(createBookingsPanel(), "MY_BOOKINGS");
        mainContentPanel.add(createRatingsPanel(), "RATINGS");
        mainContentPanel.add(createProfilePanel(), "PROFILE");
        
        add(mainContentPanel, BorderLayout.CENTER);
        
        // Show dashboard by default
        cardLayout.show(mainContentPanel, "DASHBOARD");
    }
    
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(0, 102, 204));
        header.setPreferredSize(new Dimension(1000, 60));
        
        JLabel titleLabel = new JLabel("✈️ Tourist Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        header.add(titleLabel, BorderLayout.WEST);
        
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);
        
        JLabel userLabel = new JLabel("Welcome, " + currentTourist.getName());
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        rightPanel.add(userLabel);
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(204, 0, 0));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> logout());
        rightPanel.add(logoutBtn);
        
        header.add(rightPanel, BorderLayout.EAST);
        
        return header;
    }
    
    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(240, 240, 240));
        sidebar.setPreferredSize(new Dimension(200, 700));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        
        String[] menuItems = {"Dashboard", "Book Tour", "My Bookings", "Rate Bookings", "Profile"};
        String[] icons = {"🏠", "✈️", "📋", "⭐", "👤"};
        
        for (int i = 0; i < menuItems.length; i++) {
            JButton btn = createSidebarButton(icons[i] + " " + menuItems[i]);
            final String panelName = getPanelName(menuItems[i]);
            btn.addActionListener(e -> {
                cardLayout.show(mainContentPanel, panelName);
                if (panelName.equals("MY_BOOKINGS")) refreshBookingsTable();
                if (panelName.equals("RATINGS")) refreshRatingsPanel();
            });
            sidebar.add(btn);
            sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        }
        
        return sidebar;
    }
    
    private String getPanelName(String menuItem) {
        switch(menuItem) {
            case "Dashboard": return "DASHBOARD";
            case "Book Tour": return "BOOK_TOUR";
            case "My Bookings": return "MY_BOOKINGS";
            case "Rate Bookings": return "RATINGS";
            case "Profile": return "PROFILE";
            default: return "DASHBOARD";
        }
    }
    
    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(180, 40));
        btn.setPreferredSize(new Dimension(180, 40));
        btn.setFont(new Font("Arial", Font.PLAIN, 14));
        btn.setBackground(Color.WHITE);
        btn.setForeground(Color.BLACK);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        return btn;
    }
    
    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        // Welcome Card
        JPanel welcomeCard = new JPanel();
        welcomeCard.setBackground(new Color(0, 153, 76));
        welcomeCard.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        welcomeCard.setLayout(new BorderLayout());
        
        JLabel welcomeLabel = new JLabel("Welcome back, " + currentTourist.getName() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeCard.add(welcomeLabel, BorderLayout.NORTH);
        
        JLabel messageLabel = new JLabel("Your travel journey continues! Explore new destinations.");
        messageLabel.setForeground(Color.WHITE);
        welcomeCard.add(messageLabel, BorderLayout.CENTER);
        
        panel.add(welcomeCard, BorderLayout.NORTH);
        
        // Stats Panel
        JPanel statsPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        statsPanel.setBackground(Color.WHITE);
        
        ArrayList<Booking> bookings = FileHandler.getBookingsByTourist(touristId);
        int total = bookings.size();
        int pending = 0;
        int confirmed = 0;
        for (Booking b : bookings) {
            if (b.getStatus().equals("Pending")) pending++;
            if (b.getStatus().equals("Confirmed")) confirmed++;
        }
        
        statsPanel.add(createStatCard("Total Bookings", String.valueOf(total)));
        statsPanel.add(createStatCard("Pending", String.valueOf(pending)));
        statsPanel.add(createStatCard("Confirmed", String.valueOf(confirmed)));
        
        panel.add(statsPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createStatCard(String title, String value) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        titleLabel.setForeground(Color.GRAY);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(new Color(0, 102, 204));
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createBookTourPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("Book a New Tour");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Destination
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Destination:"), gbc);
        
        ArrayList<Destination> destinations = FileHandler.loadDestinations();
        JComboBox<Destination> destCombo = new JComboBox<>(destinations.toArray(new Destination[0]));
        destCombo.setPreferredSize(new Dimension(200, 25));
        gbc.gridx = 1;
        formPanel.add(destCombo, gbc);
        
        // Package
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Tour Package:"), gbc);
        
        ArrayList<TourPackage> packages = FileHandler.loadPackages();
        JComboBox<TourPackage> packageCombo = new JComboBox<>(packages.toArray(new TourPackage[0]));
        packageCombo.setPreferredSize(new Dimension(200, 25));
        gbc.gridx = 1;
        formPanel.add(packageCombo, gbc);
        
        // Hotel
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Hotel:"), gbc);
        
        ArrayList<Hotel> hotels = FileHandler.loadHotels();
        JComboBox<Hotel> hotelCombo = new JComboBox<>(hotels.toArray(new Hotel[0]));
        hotelCombo.setPreferredSize(new Dimension(200, 25));
        gbc.gridx = 1;
        formPanel.add(hotelCombo, gbc);
        
        // Guide
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Tour Guide:"), gbc);
        
        ArrayList<TourGuide> guides = FileHandler.loadGuides();
        JComboBox<TourGuide> guideCombo = new JComboBox<>(guides.toArray(new TourGuide[0]));
        guideCombo.setPreferredSize(new Dimension(200, 25));
        gbc.gridx = 1;
        formPanel.add(guideCombo, gbc);
        
        // Price Display
        JLabel priceLabel = new JLabel("Total Price: $0.00");
        priceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        priceLabel.setForeground(new Color(0, 153, 76));
        
        // Update price when selection changes
        ItemListener priceUpdater = e -> {
            TourPackage pkg = (TourPackage) packageCombo.getSelectedItem();
            Hotel hotel = (Hotel) hotelCombo.getSelectedItem();
            if (pkg != null && hotel != null) {
                double total = pkg.getPrice() + (hotel.getPricePerNight() * 3);
                priceLabel.setText(String.format("Total Price: $%.2f", total));
            }
        };
        packageCombo.addItemListener(priceUpdater);
        hotelCombo.addItemListener(priceUpdater);
        
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        formPanel.add(priceLabel, gbc);
        
        // Book Button
        JButton bookBtn = new JButton("Confirm Booking");
        bookBtn.setBackground(new Color(0, 153, 76));
        bookBtn.setForeground(Color.WHITE);
        bookBtn.setFont(new Font("Arial", Font.BOLD, 14));
        bookBtn.setPreferredSize(new Dimension(200, 35));
        bookBtn.addActionListener(e -> {
            Destination dest = (Destination) destCombo.getSelectedItem();
            TourPackage pkg = (TourPackage) packageCombo.getSelectedItem();
            Hotel hotel = (Hotel) hotelCombo.getSelectedItem();
            TourGuide guide = (TourGuide) guideCombo.getSelectedItem();
            
            if (dest != null && pkg != null && hotel != null && guide != null) {
                String bookingId = "BKG" + System.currentTimeMillis();
                double totalPrice = pkg.getPrice() + (hotel.getPricePerNight() * 3);
                
                Booking booking = new Booking(bookingId, touristId, currentTourist.getName(),
                    pkg.getPackageID(), pkg.getTitle(), dest.getDestinationID(), dest.getDestinationName(),
                    hotel.getHotelID(), hotel.getName(), guide.getGuideID(), guide.getName(), totalPrice);
                
                ArrayList<Booking> allBookings = FileHandler.loadBookings();
                allBookings.add(booking);
                FileHandler.saveBookings(allBookings);
                
                JOptionPane.showMessageDialog(panel, "Booking Confirmed!\nBooking ID: " + bookingId);
                refreshBookingsTable();
                cardLayout.show(mainContentPanel, "MY_BOOKINGS");
            } else {
                JOptionPane.showMessageDialog(panel, "Please select all options!");
            }
        });
        
        gbc.gridy = 5;
        formPanel.add(bookBtn, gbc);
        
        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(null);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createBookingsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("My Bookings");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);
        
        String[] columns = {"Booking ID", "Package", "Destination", "Price", "Status", "Date"};
        bookingsModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable table = new JTable(bookingsModel);
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        refreshBookingsTable();
        
        return panel;
    }
    
    private void refreshBookingsTable() {
        if (bookingsModel != null) {
            bookingsModel.setRowCount(0);
            ArrayList<Booking> bookings = FileHandler.getBookingsByTourist(touristId);
            for (Booking b : bookings) {
                bookingsModel.addRow(new String[]{
                    b.getBookingId(), 
                    b.getPackageTitle(), 
                    b.getDestinationName(),
                    "$" + String.format("%.2f", b.getTotalPrice()), 
                    b.getStatus(), 
                    b.getBookingDate()
                });
            }
        }
    }
    
    private JPanel createRatingsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("Rate Your Completed Bookings");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);
        
        // Find unrated confirmed bookings
        ArrayList<Booking> unratedBookings = new ArrayList<>();
        for (Booking b : FileHandler.getBookingsByTourist(touristId)) {
            if (b.getStatus().equals("Confirmed") && !FileHandler.hasRated(touristId, b.getBookingId())) {
                unratedBookings.add(b);
            }
        }
        
        if (unratedBookings.isEmpty()) {
            JLabel noRatingsLabel = new JLabel("No unrated bookings found. All your confirmed bookings have been rated!");
            noRatingsLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            noRatingsLabel.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(noRatingsLabel, BorderLayout.CENTER);
            return panel;
        }
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Booking:"), gbc);
        
        JComboBox<Booking> bookingCombo = new JComboBox<>(unratedBookings.toArray(new Booking[0]));
        bookingCombo.setPreferredSize(new Dimension(250, 25));
        gbc.gridx = 1;
        formPanel.add(bookingCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Rating (1-5):"), gbc);
        
        JSpinner ratingSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 5, 1));
        ratingSpinner.setPreferredSize(new Dimension(80, 25));
        gbc.gridx = 1;
        formPanel.add(ratingSpinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Comment:"), gbc);
        
        JTextArea commentArea = new JTextArea(3, 20);
        commentArea.setLineWrap(true);
        JScrollPane commentScroll = new JScrollPane(commentArea);
        commentScroll.setPreferredSize(new Dimension(250, 60));
        gbc.gridx = 1;
        formPanel.add(commentScroll, gbc);
        
        JButton submitBtn = new JButton("Submit Rating");
        submitBtn.setBackground(new Color(0, 153, 76));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFont(new Font("Arial", Font.BOLD, 14));
        submitBtn.addActionListener(e -> {
            Booking selected = (Booking) bookingCombo.getSelectedItem();
            int rating = (int) ratingSpinner.getValue();
            String comment = commentArea.getText();
            
            String ratingId = "RAT" + System.currentTimeMillis();
            Rating newRating = new Rating(ratingId, touristId, currentTourist.getName(),
                selected.getBookingId(), selected.getPackageTitle(), rating, comment);
            FileHandler.addRating(newRating);
            
            JOptionPane.showMessageDialog(panel, "Thank you for your rating!");
            refreshRatingsPanel();
            cardLayout.show(mainContentPanel, "RATINGS");
        });
        
        gbc.gridy = 3;
        formPanel.add(submitBtn, gbc);
        
        panel.add(formPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void refreshRatingsPanel() {
  
    for (Component comp : mainContentPanel.getComponents()) {
        if (comp.getName() != null && comp.getName().equals("RATINGS_PANEL")) {
            mainContentPanel.remove(comp);
            break;
        }
    }
    JPanel newPanel = createRatingsPanel();
    newPanel.setName("RATINGS_PANEL");
    mainContentPanel.add(newPanel, "RATINGS");
    mainContentPanel.revalidate();
    mainContentPanel.repaint();
    cardLayout.show(mainContentPanel, "RATINGS");
}
    
    private JPanel createProfilePanel() {
    JPanel panel = new JPanel(new GridBagLayout());
    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    panel.setBackground(Color.WHITE);
    
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    
    // Title
    JLabel title = new JLabel("My Profile");
    title.setFont(new Font("Arial", Font.BOLD, 18));
    title.setForeground(new Color(0, 102, 204));
    gbc.gridx = 0; gbc.gridy = 0;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    panel.add(title, gbc);
    
    // Reset gridwidth and anchor for other rows
    gbc.gridwidth = 1;
    gbc.anchor = GridBagConstraints.WEST;
    
    // Name - FIXED: Use separate constraints for label and value
    gbc.gridx = 0; gbc.gridy = 1;
    gbc.weightx = 0.3;
    JLabel nameLabel = new JLabel("Name:");
    nameLabel.setFont(new Font("Arial", Font.BOLD, 12));
    panel.add(nameLabel, gbc);
    
    gbc.gridx = 1;
    gbc.weightx = 0.7;
    JLabel nameValue = new JLabel(currentTourist.getName());
    nameValue.setFont(new Font("Arial", Font.PLAIN, 12));
    panel.add(nameValue, gbc);
    
    // Email
    gbc.gridx = 0; gbc.gridy = 2;
    JLabel emailLabel = new JLabel("Email:");
    emailLabel.setFont(new Font("Arial", Font.BOLD, 12));
    panel.add(emailLabel, gbc);
    
    gbc.gridx = 1;
    JLabel emailValue = new JLabel(currentTourist.getEmail());
    emailValue.setFont(new Font("Arial", Font.PLAIN, 12));
    panel.add(emailValue, gbc);
    
    // Nationality
    gbc.gridx = 0; gbc.gridy = 3;
    JLabel nationalLabel = new JLabel("Nationality:");
    nationalLabel.setFont(new Font("Arial", Font.BOLD, 12));
    panel.add(nationalLabel, gbc);
    
    gbc.gridx = 1;
    JLabel nationalValue = new JLabel(currentTourist.getNationality());
    nationalValue.setFont(new Font("Arial", Font.PLAIN, 12));
    panel.add(nationalValue, gbc);
    
    // Contact (editable)
    gbc.gridx = 0; gbc.gridy = 4;
    JLabel contactLabel = new JLabel("Contact:");
    contactLabel.setFont(new Font("Arial", Font.BOLD, 12));
    panel.add(contactLabel, gbc);
    
    gbc.gridx = 1;
    JTextField contactField = new JTextField(currentTourist.getContactNumber(), 15);
    contactField.setFont(new Font("Arial", Font.PLAIN, 12));
    panel.add(contactField, gbc);
    
    // Group Size (editable)
    gbc.gridx = 0; gbc.gridy = 5;
    JLabel groupLabel = new JLabel("Group Size:");
    groupLabel.setFont(new Font("Arial", Font.BOLD, 12));
    panel.add(groupLabel, gbc);
    
    gbc.gridx = 1;
    JSpinner groupSpinner = new JSpinner(new SpinnerNumberModel(currentTourist.getGroupSize(), 1, 20, 1));
    groupSpinner.setFont(new Font("Arial", Font.PLAIN, 12));
    panel.add(groupSpinner, gbc);
    
    // Update Button
    JButton updateBtn = new JButton("Update Profile");
    updateBtn.setBackground(new Color(0, 102, 204));
    updateBtn.setForeground(Color.WHITE);
    updateBtn.setFont(new Font("Arial", Font.BOLD, 14));
    updateBtn.setFocusPainted(false);
    updateBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    updateBtn.addActionListener(e -> {
        currentTourist.setContactNumber(contactField.getText());
        currentTourist.setGroupSize((int) groupSpinner.getValue());
        
        ArrayList<Tourist> tourists = FileHandler.loadTourists();
        for (int i = 0; i < tourists.size(); i++) {
            if (tourists.get(i).getPersonID().equals(touristId)) {
                tourists.set(i, currentTourist);
                break;
            }
        }
        FileHandler.saveTourists(tourists);
        JOptionPane.showMessageDialog(panel, "Profile updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    });
    
    gbc.gridx = 0; gbc.gridy = 6;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    panel.add(updateBtn, gbc);
    
    return panel;
}
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}