package gui;

import models.*;
import utils.FileHandler;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;

public class TourGuideGUI extends JFrame {
    private String guideId;
    private TourGuide currentGuide;
    private DefaultTableModel toursModel;
    
    public TourGuideGUI(String guideId) {
        this.guideId = guideId;
        ArrayList<TourGuide> guides = FileHandler.loadGuides();
        for (TourGuide g : guides) {
            if (g.getGuideID().equals(guideId)) {
                this.currentGuide = g;
                break;
            }
        }
        
        setTitle("Tour Guide Portal - Welcome " + currentGuide.getName());
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        setupUI();
    }
    
    private void setupUI() {
        setLayout(new BorderLayout());
        
        // Header Panel - Dark Blue
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(0, 51, 102));
        headerPanel.setPreferredSize(new Dimension(900, 70));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("TOUR GUIDE DASHBOARD");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        infoPanel.setOpaque(false);
        
        JLabel userLabel = new JLabel("Guide: " + currentGuide.getName() + " | " + currentGuide.getLanguage());
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        infoPanel.add(userLabel);
        
        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setBackground(new Color(180, 0, 0));
        logoutBtn.setForeground(Color.RED);
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 12));
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> logout());
        infoPanel.add(logoutBtn);
        
        headerPanel.add(infoPanel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);
        
        // Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.setBackground(Color.WHITE);
        
        tabbedPane.addTab("MY TOURS", createToursPanel());
        tabbedPane.addTab("AVAILABILITY", createAvailabilityPanel());
        tabbedPane.addTab("MY RATINGS", createRatingsPanel());
        
        add(tabbedPane, BorderLayout.CENTER);
    }
    
    private JPanel createToursPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("My Assigned Tours");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);
        
        String[] columns = {"Booking ID", "Tourist Name", "Package", "Destination", "Booking Date"};
        toursModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable table = new JTable(toursModel);
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.getTableHeader().setBackground(new Color(220, 220, 220));
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        table.setSelectionBackground(new Color(0, 102, 204));
        table.setSelectionForeground(Color.WHITE);
        
        refreshTours();
        
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JLabel statsLabel = new JLabel("Total Tours: " + toursModel.getRowCount());
        statsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        statsLabel.setForeground(new Color(0, 120, 0));
        statsLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        panel.add(statsLabel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void refreshTours() {
        if (toursModel != null) {
            toursModel.setRowCount(0);
            for (Booking b : FileHandler.loadBookings()) {
                if (b.getGuideId() != null && b.getGuideId().equals(guideId) && b.getStatus().equals("Confirmed")) {
                    toursModel.addRow(new String[]{
                        b.getBookingId(), 
                        b.getTouristName(),
                        b.getPackageTitle(), 
                        b.getDestinationName(), 
                        b.getBookingDate()
                    });
                }
            }
        }
    }
    
    private JPanel createAvailabilityPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Center panel for content
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Status Card - Dark Background
        JPanel statusCard = new JPanel();
        statusCard.setBackground(new Color(0, 40, 80));  // Very dark blue
        statusCard.setBorder(BorderFactory.createLineBorder(new Color(0, 80, 160), 2));
        statusCard.setLayout(new BorderLayout());
        statusCard.setMaximumSize(new Dimension(500, 130));
        statusCard.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel statusLabel = new JLabel("CURRENT STATUS");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        statusCard.add(statusLabel, BorderLayout.NORTH);
        
        String statusText = currentGuide.isAvailable() ? "AVAILABLE" : "BUSY";
        Color statusColor = currentGuide.isAvailable() ? new Color(0, 255, 0) : new Color(255, 100, 100);
        
        JLabel statusValue = new JLabel(statusText);
        statusValue.setFont(new Font("Arial", Font.BOLD, 32));
        statusValue.setForeground(statusColor);
        statusValue.setHorizontalAlignment(SwingConstants.CENTER);
        statusValue.setBorder(BorderFactory.createEmptyBorder(5, 0, 20, 0));
        statusCard.add(statusValue, BorderLayout.CENTER);
        
        centerPanel.add(Box.createVerticalGlue());
        centerPanel.add(statusCard);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 40)));
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 25, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Available Button - Dark Green
        JButton availableBtn = new JButton("MARK AS AVAILABLE");
        availableBtn.setBackground(new Color(0, 100, 0));  // Dark green
        availableBtn.setForeground(Color.GREEN);
        availableBtn.setFont(new Font("Arial", Font.BOLD, 14));
        availableBtn.setFocusPainted(false);
        availableBtn.setBorder(BorderFactory.createEmptyBorder(12, 30, 12, 30));
        availableBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        // Hover effect
        availableBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                availableBtn.setBackground(new Color(0, 130, 0));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                availableBtn.setBackground(new Color(0, 100, 0));
            }
        });
        availableBtn.addActionListener(e -> {
            currentGuide.setAvailable(true);
            ArrayList<TourGuide> guides = FileHandler.loadGuides();
            for (int i = 0; i < guides.size(); i++) {
                if (guides.get(i).getGuideID().equals(guideId)) {
                    guides.set(i, currentGuide);
                    break;
                }
            }
            FileHandler.saveGuides(guides);
            statusValue.setText("AVAILABLE");
            statusValue.setForeground(new Color(0, 255, 0));
            JOptionPane.showMessageDialog(panel, "You are now marked as AVAILABLE!");
        });
        
        // Busy Button - Dark Red
        JButton busyBtn = new JButton("MARK AS BUSY");
        busyBtn.setBackground(new Color(139, 0, 0));  // Dark red
        busyBtn.setForeground(Color.RED);
        busyBtn.setFont(new Font("Arial", Font.BOLD, 14));
        busyBtn.setFocusPainted(false);
        busyBtn.setBorder(BorderFactory.createEmptyBorder(12, 30, 12, 30));
        busyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        // Hover effect
        busyBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                busyBtn.setBackground(new Color(180, 0, 0));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                busyBtn.setBackground(new Color(139, 0, 0));
            }
        });
        busyBtn.addActionListener(e -> {
            currentGuide.setAvailable(false);
            ArrayList<TourGuide> guides = FileHandler.loadGuides();
            for (int i = 0; i < guides.size(); i++) {
                if (guides.get(i).getGuideID().equals(guideId)) {
                    guides.set(i, currentGuide);
                    break;
                }
            }
            FileHandler.saveGuides(guides);
            statusValue.setText("BUSY");
            statusValue.setForeground(new Color(255, 100, 100));
            JOptionPane.showMessageDialog(panel, "You are now marked as BUSY!");
        });
        
        buttonPanel.add(availableBtn);
        buttonPanel.add(busyBtn);
        centerPanel.add(buttonPanel);
        centerPanel.add(Box.createVerticalGlue());
        
        panel.add(centerPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createRatingsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("My Ratings & Feedback");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(0, 51, 102));
        panel.add(title, BorderLayout.NORTH);
        
        String[] columns = {"Rating ID", "Tourist", "Package", "Rating", "Comment", "Date"};
        DefaultTableModel ratingsModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable table = new JTable(ratingsModel);
        table.setRowHeight(35);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.getTableHeader().setBackground(new Color(220, 220, 220));
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        
        // Calculate average rating
        double totalRating = 0;
        int ratingCount = 0;
        
        for (Rating r : FileHandler.loadRatings()) {
            // Find if this rating belongs to a booking assigned to this guide
            Booking associatedBooking = null;
            for (Booking b : FileHandler.loadBookings()) {
                if (b.getBookingId().equals(r.getBookingId()) && b.getGuideId() != null && b.getGuideId().equals(guideId)) {
                    associatedBooking = b;
                    break;
                }
            }
            
            if (associatedBooking != null) {
                // Create star string
                String stars = "";
                for (int i = 0; i < r.getRatingValue(); i++) stars += "★";
                for (int i = r.getRatingValue(); i < 5; i++) stars += "☆";
                
                ratingsModel.addRow(new String[]{
                    r.getRatingId(), r.getTouristName(), r.getPackageTitle(),
                    stars, r.getComment(), r.getRatingDate()
                });
                totalRating += r.getRatingValue();
                ratingCount++;
            }
        }
        
        double averageRating = ratingCount > 0 ? totalRating / ratingCount : 0;
        
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Stats Panel at bottom
        JPanel statsPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        statsPanel.setBackground(Color.WHITE);
        
        JPanel ratingCard = new JPanel();
        ratingCard.setBackground(new Color(255, 245, 200));
        ratingCard.setBorder(BorderFactory.createLineBorder(new Color(200, 150, 0), 1));
        ratingCard.setLayout(new BorderLayout());
        
        JLabel ratingLabel = new JLabel("Average Rating");
        ratingLabel.setFont(new Font("Arial", Font.BOLD, 12));
        ratingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        ratingLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
        ratingCard.add(ratingLabel, BorderLayout.NORTH);
        
        JLabel ratingValue = new JLabel(String.format("%.1f / 5.0", averageRating));
        ratingValue.setFont(new Font("Arial", Font.BOLD, 20));
        ratingValue.setForeground(new Color(200, 100, 0));
        ratingValue.setHorizontalAlignment(SwingConstants.CENTER);
        ratingValue.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        ratingCard.add(ratingValue, BorderLayout.CENTER);
        
        JPanel countCard = new JPanel();
        countCard.setBackground(new Color(200, 220, 240));
        countCard.setBorder(BorderFactory.createLineBorder(new Color(0, 70, 140), 1));
        countCard.setLayout(new BorderLayout());
        
        JLabel countLabel = new JLabel("Total Ratings Received");
        countLabel.setFont(new Font("Arial", Font.BOLD, 12));
        countLabel.setHorizontalAlignment(SwingConstants.CENTER);
        countLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
        countCard.add(countLabel, BorderLayout.NORTH);
        
        JLabel countValue = new JLabel(String.valueOf(ratingCount));
        countValue.setFont(new Font("Arial", Font.BOLD, 20));
        countValue.setForeground(new Color(0, 70, 140));
        countValue.setHorizontalAlignment(SwingConstants.CENTER);
        countValue.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        countCard.add(countValue, BorderLayout.CENTER);
        
        statsPanel.add(ratingCard);
        statsPanel.add(countCard);
        panel.add(statsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}