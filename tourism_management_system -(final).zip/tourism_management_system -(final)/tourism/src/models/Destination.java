package models;

import java.io.Serializable;

public class Destination implements Serializable {
    private String destinationID;
    private String destinationName;
    private String country;
    private String description;
    private double rating;

    public Destination(String destinationID, String destinationName, String country,
                       String description, double rating) {
        this.destinationID = destinationID;
        this.destinationName = destinationName;
        this.country = country;
        this.description = description;
        this.rating = rating;
    }

    public String getDestinationID() { return destinationID; }
    public String getDestinationName() { return destinationName; }
    public String getCountry() { return country; }
    public String getDescription() { return description; }
    public double getRating() { return rating; }

    public void setDestinationName(String destinationName) { this.destinationName = destinationName; }
    public void setCountry(String country) { this.country = country; }
    public void setDescription(String description) { this.description = description; }
    public void setRating(double rating) { this.rating = rating; }

    public String toFileString() {
        return destinationID + "," + destinationName + "," + country + "," + description + "," + rating;
    }

    public static Destination fromFileString(String line) {
        try {
            String[] p = line.split(",");
            return new Destination(p[0], p[1], p[2], p[3], Double.parseDouble(p[4]));
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return destinationName + " (" + country + ") - " + rating + " stars";
    }
}
