package models;

import java.io.Serializable;

public class Hotel implements Serializable {
    private String hotelID;
    private String name;
    private String location;
    private int starRating;
    private double pricePerNight;
    private int availableRooms;
    public static int hotelCount = 0;
    public static final double TAX_RATE = 0.15;

    public Hotel(String hotelID, String name, String location, int starRating,
                 double pricePerNight, int availableRooms) {
        this.hotelID = hotelID;
        this.name = name;
        this.location = location;
        this.starRating = starRating;
        this.pricePerNight = pricePerNight;
        this.availableRooms = availableRooms;
        hotelCount++;
    }

    public String getHotelID() { return hotelID; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public int getStarRating() { return starRating; }
    public double getPricePerNight() { return pricePerNight; }
    public int getAvailableRooms() { return availableRooms; }

    public void setName(String name) { this.name = name; }
    public void setLocation(String location) { this.location = location; }
    public void setStarRating(int starRating) { this.starRating = starRating; }
    public void setPricePerNight(double pricePerNight) { this.pricePerNight = pricePerNight; }
    public void setAvailableRooms(int availableRooms) { this.availableRooms = availableRooms; }

    public boolean checkAvailability(int roomsRequested) {
        return availableRooms >= roomsRequested;
    }

    public double calculateTotalPrice(int nights) {
        double total = pricePerNight * nights;
        return total + (total * TAX_RATE);
    }

    public String toFileString() {
        return hotelID + "," + name + "," + location + "," + starRating + "," + pricePerNight + "," + availableRooms;
    }

    public static Hotel fromFileString(String line) {
        try {
            String[] p = line.split(",");
            return new Hotel(p[0], p[1], p[2], Integer.parseInt(p[3]),
                    Double.parseDouble(p[4]), Integer.parseInt(p[5]));
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return name + " (" + location + ") " + starRating + " stars - $" + pricePerNight + "/night";
    }
}
