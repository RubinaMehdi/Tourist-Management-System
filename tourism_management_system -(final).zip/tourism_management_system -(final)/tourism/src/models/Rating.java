package models;

import java.io.Serializable;

public class Rating implements Serializable {
    private String ratingId;
    private String touristId;
    private String touristName;
    private String bookingId;
    private String packageTitle;
    private int ratingValue;
    private String comment;
    private String ratingDate;

    public Rating(String ratingId, String touristId, String touristName,
                  String bookingId, String packageTitle, int ratingValue, String comment) {
        this.ratingId = ratingId;
        this.touristId = touristId;
        this.touristName = touristName;
        this.bookingId = bookingId;
        this.packageTitle = packageTitle;
        this.ratingValue = ratingValue;
        this.comment = comment;
        this.ratingDate = java.time.LocalDate.now().toString();
    }

    public String getRatingId() { return ratingId; }
    public String getTouristId() { return touristId; }
    public String getTouristName() { return touristName; }
    public String getBookingId() { return bookingId; }
    public String getPackageTitle() { return packageTitle; }
    public int getRatingValue() { return ratingValue; }
    public String getComment() { return comment; }
    public String getRatingDate() { return ratingDate; }

    public void setComment(String comment) { this.comment = comment; }
    public void setRatingValue(int ratingValue) { this.ratingValue = ratingValue; }

    public String toFileString() {
        return ratingId + "," + touristId + "," + touristName + "," +
                bookingId + "," + packageTitle + "," + ratingValue + "," +
                comment + "," + ratingDate;
    }

    public static Rating fromFileString(String line) {
        try {
            String[] p = line.split(",");
            return new Rating(p[0], p[1], p[2], p[3], p[4],
                    Integer.parseInt(p[5]), p[6]);
        } catch (Exception e) {
            return null;
        }
    }
}
