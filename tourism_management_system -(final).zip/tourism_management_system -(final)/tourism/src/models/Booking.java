package models;

import java.io.Serializable;

public class Booking implements Serializable {
    private String bookingId;
    private String touristId;
    private String touristName;
    private String packageId;
    private String packageTitle;
    private String destinationId;
    private String destinationName;
    private String hotelId;
    private String hotelName;
    private String guideId;
    private String guideName;
    private String transportId;
    private String transportType;
    private double transportFare;
    private double totalPrice;
    private String status;
    private String bookingDate;
    private double distanceKm;
    
    public Booking(String bookingId, String touristId, String touristName,
                   String packageId, String packageTitle, String destinationId,
                   String destinationName, String hotelId, String hotelName,
                   String guideId, String guideName, double totalPrice) {
        this.bookingId = bookingId;
        this.touristId = touristId;
        this.touristName = touristName;
        this.packageId = packageId;
        this.packageTitle = packageTitle;
        this.destinationId = destinationId;
        this.destinationName = destinationName;
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.guideId = guideId;
        this.guideName = guideName;
        this.totalPrice = totalPrice;
        this.status = "Pending";
        this.bookingDate = java.time.LocalDate.now().toString();
        this.transportId = "";
        this.transportType = "Not Selected";
        this.transportFare = 0;
        this.distanceKm = 0;
    }
    
    // Full constructor with transport
    public Booking(String bookingId, String touristId, String touristName,
                   String packageId, String packageTitle, String destinationId,
                   String destinationName, String hotelId, String hotelName,
                   String guideId, String guideName, String transportId,
                   String transportType, double transportFare, double distanceKm, double totalPrice) {
        this.bookingId = bookingId;
        this.touristId = touristId;
        this.touristName = touristName;
        this.packageId = packageId;
        this.packageTitle = packageTitle;
        this.destinationId = destinationId;
        this.destinationName = destinationName;
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.guideId = guideId;
        this.guideName = guideName;
        this.transportId = transportId;
        this.transportType = transportType;
        this.transportFare = transportFare;
        this.distanceKm = distanceKm;
        this.totalPrice = totalPrice + transportFare;
        this.status = "Pending";
        this.bookingDate = java.time.LocalDate.now().toString();
    }
    
    // Getters
    public String getBookingId() { return bookingId; }
    public String getTouristId() { return touristId; }
    public String getTouristName() { return touristName; }
    public String getPackageId() { return packageId; }
    public String getPackageTitle() { return packageTitle; }
    public String getDestinationId() { return destinationId; }
    public String getDestinationName() { return destinationName; }
    public String getHotelId() { return hotelId; }
    public String getHotelName() { return hotelName; }
    public String getGuideId() { return guideId; }
    public String getGuideName() { return guideName; }
    public String getTransportId() { return transportId; }
    public String getTransportType() { return transportType; }
    public double getTransportFare() { return transportFare; }
    public double getTotalPrice() { return totalPrice; }
    public String getStatus() { return status; }
    public String getBookingDate() { return bookingDate; }
    public double getDistanceKm() { return distanceKm; }
    
    public void setStatus(String status) { this.status = status; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
    public void setTransportId(String transportId) { this.transportId = transportId; }
    public void setTransportType(String transportType) { this.transportType = transportType; }
    public void setTransportFare(double transportFare) { this.transportFare = transportFare; }
    
    public String toFileString() {
        return bookingId + "," + touristId + "," + touristName + "," +
               packageId + "," + packageTitle + "," + destinationId + "," +
               destinationName + "," + hotelId + "," + hotelName + "," +
               guideId + "," + guideName + "," + transportId + "," +
               transportType + "," + transportFare + "," + distanceKm + "," +
               totalPrice + "," + status + "," + bookingDate;
    }
    
    public static Booking fromFileString(String line) {
    try {
        String[] p = line.split(",");
        if (p.length >= 18) {
            // All fields including transport
            Booking b = new Booking(p[0], p[1], p[2], p[3], p[4], p[5], p[6], 
                                    p[7], p[8], p[9], p[10], p[11], p[12], 
                                    Double.parseDouble(p[13]), Double.parseDouble(p[14]), 
                                    Double.parseDouble(p[15]));
            b.setStatus(p[16]);
            b.bookingDate = p[17];
            return b;
        } else if (p.length >= 13) {
            // Old format without transport
            Booking b = new Booking(p[0], p[1], p[2], p[3], p[4], p[5], p[6], 
                                    p[7], p[8], p[9], p[10], Double.parseDouble(p[11]));
            b.setStatus(p[12]);
            if (p.length > 13) b.bookingDate = p[13];
            return b;
        }
        return null;
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
    
    public String[] toTableRow() {
        return new String[]{bookingId, packageTitle, destinationName, transportType,
                           String.format("$%.2f", totalPrice), status, bookingDate};
    }
}