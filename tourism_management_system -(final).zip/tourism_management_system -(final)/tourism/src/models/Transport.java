package models;

import java.io.Serializable;

public class Transport implements Serializable {
    private String transportID;
    private String transportType;
    private int capacity;
    private String routeFrom;
    private String routeTo;
    private double pricePerKm;
    private boolean available;
    private String vehicleNumber;
    private String amenities;
    public static int transportCount = 0;
    public static final int MAX_CAPACITY = 60;
    
    public Transport(String transportID, String transportType, int capacity, 
                     String routeFrom, String routeTo, double pricePerKm) {
        this.transportID = transportID;
        this.transportType = transportType;
        this.capacity = capacity;
        this.routeFrom = routeFrom;
        this.routeTo = routeTo;
        this.pricePerKm = pricePerKm;
        this.available = true;
        this.vehicleNumber = "VEH" + transportCount;
        this.amenities = "Basic";
        transportCount++;
    }
    
    public Transport(String transportID, String transportType, int capacity, 
                     String routeFrom, String routeTo, double pricePerKm, 
                     String vehicleNumber, String amenities) {
        this.transportID = transportID;
        this.transportType = transportType;
        this.capacity = capacity;
        this.routeFrom = routeFrom;
        this.routeTo = routeTo;
        this.pricePerKm = pricePerKm;
        this.available = true;
        this.vehicleNumber = vehicleNumber;
        this.amenities = amenities;
        transportCount++;
    }
    
    // Getters
    public String getTransportID() { return transportID; }
    public String getTransportType() { return transportType; }
    public int getCapacity() { return capacity; }
    public String getRouteFrom() { return routeFrom; }
    public String getRouteTo() { return routeTo; }
    public double getPricePerKm() { return pricePerKm; }
    public boolean isAvailable() { return available; }
    public String getVehicleNumber() { return vehicleNumber; }
    public String getAmenities() { return amenities; }
    
    // Setters
    public void setTransportType(String transportType) { this.transportType = transportType; }
    public void setCapacity(int capacity) { this.capacity = Math.min(capacity, MAX_CAPACITY); }
    public void setRouteFrom(String routeFrom) { this.routeFrom = routeFrom; }
    public void setRouteTo(String routeTo) { this.routeTo = routeTo; }
    public void setPricePerKm(double pricePerKm) { this.pricePerKm = pricePerKm; }
    public void setAvailable(boolean available) { this.available = available; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }
    public void setAmenities(String amenities) { this.amenities = amenities; }
    
    public boolean checkAvailability(int requestedSeats) {
        return available && capacity >= requestedSeats;
    }
    
    public double calculateFare(double distanceKm) {
        return pricePerKm * distanceKm;
    }
    
    public String toFileString() {
        return transportID + "," + transportType + "," + capacity + "," + 
               routeFrom + "," + routeTo + "," + pricePerKm + "," + 
               available + "," + vehicleNumber + "," + amenities;
    }
    
    public static Transport fromFileString(String line) {
        try {
            String[] parts = line.split(",");
            Transport t = new Transport(parts[0], parts[1], Integer.parseInt(parts[2]), 
                                        parts[3], parts[4], Double.parseDouble(parts[5]),
                                        parts[7], parts[8]);
            t.available = Boolean.parseBoolean(parts[6]);
            return t;
        } catch (Exception e) {
            return null;
        }
    }
    
    @Override
    public String toString() {
        return transportType + " (" + vehicleNumber + ") | " + routeFrom + " → " + routeTo + 
               " | Capacity: " + capacity + " | $" + pricePerKm + "/km" + 
               (available ? "  Available" : "  Booked");
    }
}