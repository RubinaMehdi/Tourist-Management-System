package models;

import java.io.Serializable;
import java.util.ArrayList;

public class TourPackage implements Serializable {
    private String packageID;
    private String title;
    private String description;
    private double price;
    private int duration;
    private ArrayList<String> extras;

    public TourPackage(String packageID, String title, String description, double price, int duration) {
        this.packageID = packageID;
        this.title = title;
        this.description = description;
        this.price = price;
        this.duration = duration;
        this.extras = new ArrayList<>();
    }

    public TourPackage(String packageID, String title, double price, int duration) {
        this(packageID, title, "Standard tour package", price, duration);
    }

    public String getPackageID() { return packageID; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getDuration() { return duration; }
    public ArrayList<String> getExtras() { return extras; }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setPrice(double price) { this.price = price; }
    public void setDuration(int duration) { this.duration = duration; }

    public void addExtra(String extra) {
        extras.add(extra);
    }

    public String toFileString() {
        return packageID + "," + title + "," + description + "," + price + "," + duration;
    }

    public static TourPackage fromFileString(String line) {
        try {
            String[] p = line.split(",");
            return new TourPackage(p[0], p[1], p[2], Double.parseDouble(p[3]), Integer.parseInt(p[4]));
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return title + " - $" + price + " (" + duration + " days)";
    }
}
