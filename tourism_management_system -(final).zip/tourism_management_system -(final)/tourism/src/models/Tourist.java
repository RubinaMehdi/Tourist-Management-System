package models;

import utils.FileHandler;
import java.util.*;

public class Tourist extends Person {
    private String nationality;
    private String passportNumber;
    private String contactNumber;
    private int groupSize;
    private ArrayList<String> preferences;
    private static int touristCount = 0;

    public Tourist(String personID, String name, String email, String password,
                   String nationality, String passportNumber, String contactNumber, int groupSize) {
        super(personID, name, email, password);
        this.nationality = nationality;
        this.passportNumber = passportNumber;
        this.contactNumber = contactNumber;
        this.groupSize = groupSize;
        this.preferences = new ArrayList<>();
        touristCount++;
    }

    public String getNationality() { return nationality; }
    public String getPassportNumber() { return passportNumber; }
    public String getContactNumber() { return contactNumber; }
    public int getGroupSize() { return groupSize; }
    public ArrayList<String> getPreferences() { return preferences; }
    public static int getTouristCount() { return touristCount; }

    public void setNationality(String nationality) { this.nationality = nationality; }
    public void setPassportNumber(String passportNumber) { this.passportNumber = passportNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public void setGroupSize(int groupSize) { this.groupSize = groupSize; }

    public void addPreference(String preference) {
        preferences.add(preference);
        FileHandler.updateTourist(this);
    }

    public void viewPreferences() {
        if (preferences.isEmpty()) {
            System.out.println("No preferences added yet.");
        } else {
            System.out.println("==== PREFERENCES ====");
            for (String p : preferences) {
                System.out.println(" - " + p);
            }
        }
    }

    public void updatePreference(int index, String newPreference) {
        if (index >= 0 && index < preferences.size()) {
            preferences.set(index, newPreference);
            FileHandler.updateTourist(this);
        }
    }

    public void deletePreference(String preference) {
        preferences.remove(preference);
        FileHandler.updateTourist(this);
    }

    @Override
    public void displayDetails() {
        System.out.println("==== TOURIST DETAILS ====");
        System.out.println("ID: " + personID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Nationality: " + nationality);
        System.out.println("Contact: " + contactNumber);
        System.out.println("Group Size: " + groupSize);
    }

    @Override
    public void showMenu() {
        System.out.println("1. View Packages\n2. Book Tour\n3. View Bookings\n4. Give Rating\n5. Logout");
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Tourist");
    }

    public String toFileString() {
        return personID + "," + name + "," + email + "," + password + "," +
                nationality + "," + passportNumber + "," + contactNumber + "," + groupSize;
    }

    public static Tourist fromFileString(String line) {
        try {
            String[] p = line.split(",");
            return new Tourist(p[0], p[1], p[2], p[3], p[4], p[5], p[6], Integer.parseInt(p[7]));
        } catch (Exception e) {
            return null;
        }
    }
}
