package models;

import utils.FileHandler;
import java.util.*;

public class TourGuide extends Person {
    private String guideID;
    private String language;
    private String expertise;
    private boolean available;
    private ArrayList<String> assignedTours;

    public TourGuide(String personID, String name, String email, String password,
                     String guideID, String language, String expertise) {
        super(personID, name, email, password);
        this.guideID = guideID;
        this.language = language;
        this.expertise = expertise;
        this.available = true;
        this.assignedTours = new ArrayList<>();
    }

    public String getGuideID() { return guideID; }
    public String getLanguage() { return language; }
    public String getExpertise() { return expertise; }
    public boolean isAvailable() { return available; }
    public ArrayList<String> getAssignedTours() { return assignedTours; }

    public void setLanguage(String language) { this.language = language; }
    public void setExpertise(String expertise) { this.expertise = expertise; }
    public void setAvailable(boolean available) { this.available = available; }

    public void updateAvailability(boolean status) {
        this.available = status;
        FileHandler.updateGuide(this);
    }

    public void assignTour(String tourId) {
        if (!assignedTours.contains(tourId)) {
            assignedTours.add(tourId);
            FileHandler.updateGuide(this);
        }
    }

    public ArrayList<Booking> getMyTours() {
        return FileHandler.getBookingsByGuide(guideID);
    }

    public double getAverageRating() {
        ArrayList<Rating> ratings = FileHandler.getRatingsByGuide(guideID);
        if (ratings.isEmpty()) return 0;
        double sum = 0;
        for (Rating r : ratings) {
            sum += r.getRatingValue();
        }
        return sum / ratings.size();
    }

    @Override
    public void displayDetails() {
        System.out.println("Guide: " + name + " | " + language + " | " + expertise + " | " + (available ? "Available" : "Busy"));
    }

    @Override
    public void showMenu() {
        System.out.println("1. View My Tours\n2. Update Availability\n3. View Ratings\n4. Logout");
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Tour Guide");
    }

    public String toFileString() {
        return personID + "," + name + "," + email + "," + password + "," +
                guideID + "," + language + "," + expertise + "," + available;
    }

    public static TourGuide fromFileString(String line) {
        try {
            String[] p = line.split(",");
            TourGuide g = new TourGuide(p[0], p[1], p[2], p[3], p[4], p[5], p[6]);
            g.available = Boolean.parseBoolean(p[7]);
            return g;
        } catch (Exception e) {
            return null;
        }
    }
}
