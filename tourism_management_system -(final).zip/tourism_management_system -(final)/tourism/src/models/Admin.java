package models;

import utils.FileHandler;
import java.util.*;

public class Admin extends Person {
    private int adminLevel;
    private String department;
    private ArrayList<String> logStorage;

    public Admin(String personID, String name, String email, String password, int adminLevel, String department) {
        super(personID, name, email, password);
        this.adminLevel = adminLevel;
        this.department = department;
        this.logStorage = new ArrayList<>();
    }

    public int getAdminLevel() { return adminLevel; }
    public String getDepartment() { return department; }
    public void setAdminLevel(int adminLevel) { this.adminLevel = adminLevel; }
    public void setDepartment(String department) { this.department = department; }

    public void addLog(String log) {
        logStorage.add(log);
        System.out.println("[LOG]: " + log);
    }

    public ArrayList<String> getLogs() { return logStorage; }

    public void addHotel(Hotel hotel) {
        ArrayList<Hotel> hotels = FileHandler.loadHotels();
        hotels.add(hotel);
        FileHandler.saveHotels(hotels);
        addLog("Admin added hotel: " + hotel.getName());
    }

    public void deleteHotel(String hotelId) {
        ArrayList<Hotel> hotels = FileHandler.loadHotels();
        hotels.removeIf(h -> h.getHotelID().equals(hotelId));
        FileHandler.saveHotels(hotels);
        addLog("Admin deleted hotel: " + hotelId);
    }

    public void addDestination(Destination dest) {
        ArrayList<Destination> destinations = FileHandler.loadDestinations();
        destinations.add(dest);
        FileHandler.saveDestinations(destinations);
        addLog("Admin added destination: " + dest.getDestinationName());
    }

    public void deleteDestination(String destId) {
        ArrayList<Destination> destinations = FileHandler.loadDestinations();
        destinations.removeIf(d -> d.getDestinationID().equals(destId));
        FileHandler.saveDestinations(destinations);
        addLog("Admin deleted destination: " + destId);
    }

    public void addPackage(TourPackage pkg) {
        ArrayList<TourPackage> packages = FileHandler.loadPackages();
        packages.add(pkg);
        FileHandler.savePackages(packages);
        addLog("Admin added package: " + pkg.getTitle());
    }

    public void deletePackage(String pkgId) {
        ArrayList<TourPackage> packages = FileHandler.loadPackages();
        packages.removeIf(p -> p.getPackageID().equals(pkgId));
        FileHandler.savePackages(packages);
        addLog("Admin deleted package: " + pkgId);
    }

    public void approveBooking(String bookingId) {
        ArrayList<Booking> bookings = FileHandler.loadBookings();
        for (Booking b : bookings) {
            if (b.getBookingId().equals(bookingId)) {
                b.setStatus("Confirmed");
                break;
            }
        }
        FileHandler.saveBookings(bookings);
        addLog("Admin approved booking: " + bookingId);
    }

    public void rejectBooking(String bookingId) {
        ArrayList<Booking> bookings = FileHandler.loadBookings();
        bookings.removeIf(b -> b.getBookingId().equals(bookingId));
        FileHandler.saveBookings(bookings);
        addLog("Admin rejected booking: " + bookingId);
    }

    public void addGuide(TourGuide guide) {
        ArrayList<TourGuide> guides = FileHandler.loadGuides();
        guides.add(guide);
        FileHandler.saveGuides(guides);
        addLog("Admin added guide: " + guide.getName());
    }

    @Override
    public void displayDetails() {
        System.out.println("Admin: " + name + " (Level " + adminLevel + ") - " + department);
    }

    @Override
    public void showMenu() {
        System.out.println("1. Manage Hotels\n2. Manage Destinations\n3. Manage Packages\n4. Manage Bookings\n5. Manage Guides\n6. Logout");
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Administrator");
    }
}
