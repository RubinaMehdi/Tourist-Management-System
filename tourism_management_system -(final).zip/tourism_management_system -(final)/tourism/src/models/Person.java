package models;

import java.io.Serializable;

public abstract class Person implements Serializable {
    protected String personID;
    protected String name;
    protected String email;
    protected String password;

    public Person(String personID, String name, String email, String password) {
        this.personID = personID;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getPersonID() { return personID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }

    public void setPersonID(String personID) { this.personID = personID; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }

    public boolean login(String email, String password) {
        return this.email.equals(email) && this.password.equals(password);
    }

    public void logout() {
        System.out.println(name + " has logged out.");
    }

    public String getProfile() {
        return "ID: " + personID + "\nName: " + name + "\nEmail: " + email;
    }

    public void changePassword(String oldPassword, String newPassword) {
        if (this.password.equals(oldPassword)) {
            this.password = newPassword;
            System.out.println("Password changed successfully!");
        } else {
            System.out.println("Old password is incorrect.");
        }
    }

    public abstract void displayDetails();
    public abstract void showMenu();
    public abstract void displayRole();
}
