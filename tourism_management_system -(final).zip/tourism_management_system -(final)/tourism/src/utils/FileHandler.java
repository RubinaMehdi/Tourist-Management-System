package utils;

import models.*;
import java.util.*;
import java.io.*;

public class FileHandler {
    
    // File paths
    private static final String DATA_DIR = "data";
    private static final String TOURIST_FILE = DATA_DIR + "/tourists.txt";
    private static final String GUIDE_FILE = DATA_DIR + "/guides.txt";
    private static final String BOOKING_FILE = DATA_DIR + "/bookings.txt";
    private static final String DESTINATION_FILE = DATA_DIR + "/destinations.txt";
    private static final String HOTEL_FILE = DATA_DIR + "/hotels.txt";
    private static final String PACKAGE_FILE = DATA_DIR + "/packages.txt";
    private static final String RATING_FILE = DATA_DIR + "/ratings.txt";
    private static final String TRANSPORT_FILE = DATA_DIR + "/transports.txt";
    
    static {
        // Create data directory if it doesn't exist
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        initializeDefaultData();
    }
    
    private static void initializeDefaultData() {
        // Initialize default hotels
        if (!new File(HOTEL_FILE).exists()) {
            ArrayList<Hotel> defaultHotels = new ArrayList<>();
            defaultHotels.add(new Hotel("H001", "Grand Plaza", "Paris", 5, 250.0, 20));
            defaultHotels.add(new Hotel("H002", "Beijing Inn", "Beijing", 4, 120.0, 30));
            defaultHotels.add(new Hotel("H003", "Andean Lodge", "Cusco", 4, 150.0, 15));
            defaultHotels.add(new Hotel("H004", "Royal Palace", "Agra", 5, 200.0, 25));
            defaultHotels.add(new Hotel("H005", "Desert Oasis", "Dubai", 5, 300.0, 18));
            saveHotels(defaultHotels);
        }
        
        // Initialize default destinations
        if (!new File(DESTINATION_FILE).exists()) {
            ArrayList<Destination> defaultDestinations = new ArrayList<>();
            defaultDestinations.add(new Destination("D001", "Eiffel Tower", "France", "Iconic Paris landmark with breathtaking views", 4.8));
            defaultDestinations.add(new Destination("D002", "Great Wall", "China", "Ancient Chinese wonder stretching thousands of miles", 4.9));
            defaultDestinations.add(new Destination("D003", "Machu Picchu", "Peru", "Incan citadel set high in the Andes Mountains", 4.9));
            defaultDestinations.add(new Destination("D004", "Taj Mahal", "India", "Mughal architecture marvel and symbol of love", 4.8));
            defaultDestinations.add(new Destination("D005", "Colosseum", "Italy", "Ancient Roman amphitheater in Rome", 4.7));
            saveDestinations(defaultDestinations);
        }
        
        // Initialize default packages
        if (!new File(PACKAGE_FILE).exists()) {
            ArrayList<TourPackage> defaultPackages = new ArrayList<>();
            defaultPackages.add(new TourPackage("P001", "Paris Romance", "Romantic getaway in Paris", 899.0, 5));
            defaultPackages.add(new TourPackage("P002", "China Discovery", "Explore the wonders of China", 1299.0, 7));
            defaultPackages.add(new TourPackage("P003", "Peru Adventure", "Adventure in the Andes", 1099.0, 6));
            defaultPackages.add(new TourPackage("P004", "India Heritage", "Discover Indian culture", 799.0, 5));
            defaultPackages.add(new TourPackage("P005", "Dubai Luxury", "Luxury experience in Dubai", 1599.0, 4));
            savePackages(defaultPackages);
        }
        
        // Initialize default transports
        if (!new File(TRANSPORT_FILE).exists()) {
            ArrayList<Transport> defaultTransports = new ArrayList<>();
            defaultTransports.add(new Transport("TR001", "AC Bus", 40, "Airport", "City Center", 15.0));
            defaultTransports.add(new Transport("TR002", "Mini Van", 8, "Hotel", "Tourist Sites", 25.0));
            defaultTransports.add(new Transport("TR003", "Luxury Car", 4, "Any Location", "Any Destination", 50.0));
            defaultTransports.add(new Transport("TR004", "Tourist Train", 60, "Station", "Scenic Route", 10.0));
            defaultTransports.add(new Transport("TR005", "Jeep", 6, "Adventure Base", "Mountain Trail", 35.0));
            defaultTransports.add(new Transport("TR006", "Boat", 20, "Dock", "Island Tour", 30.0));
            saveTransports(defaultTransports);
        }
        
        // Initialize default tourist
        if (!new File(TOURIST_FILE).exists()) {
            ArrayList<Tourist> defaultTourists = new ArrayList<>();
            defaultTourists.add(new Tourist("T001", "John Doe", "john@email.com", "pass123", "American", "US123456", "+1234567890", 2));
            defaultTourists.add(new Tourist("T002", "Jane Smith", "jane@email.com", "pass123", "British", "UK789012", "+4423456789", 1));
            saveTourists(defaultTourists);
        }
        
        // Initialize default guide
        if (!new File(GUIDE_FILE).exists()) {
            ArrayList<TourGuide> defaultGuides = new ArrayList<>();
            defaultGuides.add(new TourGuide("G001", "Pierre Dupont", "pierre@email.com", "guide123", "G001", "French/English", "Historical Tours"));
            defaultGuides.add(new TourGuide("G002", "Wei Zhang", "wei@email.com", "guide123", "G002", "Mandarin/English", "Cultural Tours"));
            defaultGuides.add(new TourGuide("G003", "Carlos Ruiz", "carlos@email.com", "guide123", "G003", "Spanish/English", "Adventure Tours"));
            saveGuides(defaultGuides);
        }
    }
    
    // ========== TOURIST METHODS ==========
    public static void saveTourists(ArrayList<Tourist> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TOURIST_FILE))) {
            for (Tourist t : list) {
                pw.println(t.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving tourists: " + e.getMessage());
        }
    }
    
    public static ArrayList<Tourist> loadTourists() {
        ArrayList<Tourist> list = new ArrayList<>();
        File file = new File(TOURIST_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    Tourist t = Tourist.fromFileString(line);
                    if (t != null) list.add(t);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static Tourist findTouristById(String id) {
        for (Tourist t : loadTourists()) {
            if (t.getPersonID().equals(id)) return t;
        }
        return null;
    }
    
    public static void updateTourist(Tourist updated) {
        ArrayList<Tourist> tourists = loadTourists();
        for (int i = 0; i < tourists.size(); i++) {
            if (tourists.get(i).getPersonID().equals(updated.getPersonID())) {
                tourists.set(i, updated);
                break;
            }
        }
        saveTourists(tourists);
    }
    
    // ========== GUIDE METHODS ==========
    public static void saveGuides(ArrayList<TourGuide> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(GUIDE_FILE))) {
            for (TourGuide g : list) {
                pw.println(g.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving guides: " + e.getMessage());
        }
    }
    
    public static ArrayList<TourGuide> loadGuides() {
        ArrayList<TourGuide> list = new ArrayList<>();
        File file = new File(GUIDE_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    TourGuide g = TourGuide.fromFileString(line);
                    if (g != null) list.add(g);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static TourGuide findGuideById(String id) {
        for (TourGuide g : loadGuides()) {
            if (g.getGuideID().equals(id)) return g;
        }
        return null;
    }
    
    public static void updateGuide(TourGuide updated) {
        ArrayList<TourGuide> guides = loadGuides();
        for (int i = 0; i < guides.size(); i++) {
            if (guides.get(i).getGuideID().equals(updated.getGuideID())) {
                guides.set(i, updated);
                break;
            }
        }
        saveGuides(guides);
    }
    
    // ========== BOOKING METHODS ==========
    public static void saveBookings(ArrayList<Booking> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(BOOKING_FILE))) {
            for (Booking b : list) {
                pw.println(b.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving bookings: " + e.getMessage());
        }
    }
    
    public static ArrayList<Booking> loadBookings() {
        ArrayList<Booking> list = new ArrayList<>();
        File file = new File(BOOKING_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    Booking b = Booking.fromFileString(line);
                    if (b != null) list.add(b);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static ArrayList<Booking> getBookingsByTourist(String touristId) {
        ArrayList<Booking> result = new ArrayList<>();
        for (Booking b : loadBookings()) {
            if (b.getTouristId().equals(touristId)) {
                result.add(b);
            }
        }
        return result;
    }
    
    public static ArrayList<Booking> getBookingsByGuide(String guideId) {
        ArrayList<Booking> result = new ArrayList<>();
        for (Booking b : loadBookings()) {
            if (b.getGuideId().equals(guideId) && b.getStatus().equals("Confirmed")) {
                result.add(b);
            }
        }
        return result;
    }
    
    public static void updateBooking(Booking updated) {
        ArrayList<Booking> bookings = loadBookings();
        for (int i = 0; i < bookings.size(); i++) {
            if (bookings.get(i).getBookingId().equals(updated.getBookingId())) {
                bookings.set(i, updated);
                break;
            }
        }
        saveBookings(bookings);
    }
    
    // ========== DESTINATION METHODS ==========
    public static void saveDestinations(ArrayList<Destination> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(DESTINATION_FILE))) {
            for (Destination d : list) {
                pw.println(d.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving destinations: " + e.getMessage());
        }
    }
    
    public static ArrayList<Destination> loadDestinations() {
        ArrayList<Destination> list = new ArrayList<>();
        File file = new File(DESTINATION_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    Destination d = Destination.fromFileString(line);
                    if (d != null) list.add(d);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static Destination findDestinationById(String id) {
        for (Destination d : loadDestinations()) {
            if (d.getDestinationID().equals(id)) return d;
        }
        return null;
    }
    
    // ========== HOTEL METHODS ==========
    public static void saveHotels(ArrayList<Hotel> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(HOTEL_FILE))) {
            for (Hotel h : list) {
                pw.println(h.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving hotels: " + e.getMessage());
        }
    }
    
    public static ArrayList<Hotel> loadHotels() {
        ArrayList<Hotel> list = new ArrayList<>();
        File file = new File(HOTEL_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    Hotel h = Hotel.fromFileString(line);
                    if (h != null) list.add(h);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static Hotel findHotelById(String id) {
        for (Hotel h : loadHotels()) {
            if (h.getHotelID().equals(id)) return h;
        }
        return null;
    }
    
    // ========== PACKAGE METHODS ==========
    public static void savePackages(ArrayList<TourPackage> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(PACKAGE_FILE))) {
            for (TourPackage p : list) {
                pw.println(p.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving packages: " + e.getMessage());
        }
    }
    
    public static ArrayList<TourPackage> loadPackages() {
        ArrayList<TourPackage> list = new ArrayList<>();
        File file = new File(PACKAGE_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    TourPackage p = TourPackage.fromFileString(line);
                    if (p != null) list.add(p);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static TourPackage findPackageById(String id) {
        for (TourPackage p : loadPackages()) {
            if (p.getPackageID().equals(id)) return p;
        }
        return null;
    }
    
    // ========== RATING METHODS ==========
    public static void saveRatings(ArrayList<Rating> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RATING_FILE))) {
            for (Rating r : list) {
                pw.println(r.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving ratings: " + e.getMessage());
        }
    }
    
    public static ArrayList<Rating> loadRatings() {
        ArrayList<Rating> list = new ArrayList<>();
        File file = new File(RATING_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    Rating r = Rating.fromFileString(line);
                    if (r != null) list.add(r);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static ArrayList<Rating> getRatingsByGuide(String guideId) {
        ArrayList<Rating> result = new ArrayList<>();
        ArrayList<Booking> guideBookings = getBookingsByGuide(guideId);
        HashSet<String> bookingIds = new HashSet<>();
        for (Booking b : guideBookings) {
            bookingIds.add(b.getBookingId());
        }
        for (Rating r : loadRatings()) {
            if (bookingIds.contains(r.getBookingId())) {
                result.add(r);
            }
        }
        return result;
    }
    
    public static boolean hasRated(String touristId, String bookingId) {
        for (Rating r : loadRatings()) {
            if (r.getTouristId().equals(touristId) && r.getBookingId().equals(bookingId)) {
                return true;
            }
        }
        return false;
    }
    
    public static void addRating(Rating rating) {
        ArrayList<Rating> ratings = loadRatings();
        ratings.add(rating);
        saveRatings(ratings);
    }
    
    // ========== TRANSPORT METHODS ==========
    public static void saveTransports(ArrayList<Transport> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TRANSPORT_FILE))) {
            for (Transport t : list) {
                pw.println(t.toFileString());
            }
        } catch (IOException e) {
            System.err.println("Error saving transports: " + e.getMessage());
        }
    }
    
    public static ArrayList<Transport> loadTransports() {
        ArrayList<Transport> list = new ArrayList<>();
        File file = new File(TRANSPORT_FILE);
        if (!file.exists()) return list;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    Transport t = Transport.fromFileString(line);
                    if (t != null) list.add(t);
                }
            }
        } catch (FileNotFoundException e) {}
        return list;
    }
    
    public static Transport findTransportById(String id) {
        for (Transport t : loadTransports()) {
            if (t.getTransportID().equals(id)) return t;
        }
        return null;
    }
    
    public static void addTransport(Transport transport) {
        ArrayList<Transport> transports = loadTransports();
        transports.add(transport);
        saveTransports(transports);
    }
    
    public static void deleteTransport(String transportId) {
        ArrayList<Transport> transports = loadTransports();
        transports.removeIf(t -> t.getTransportID().equals(transportId));
        saveTransports(transports);
    }
    
    public static void updateTransport(Transport updated) {
        ArrayList<Transport> transports = loadTransports();
        for (int i = 0; i < transports.size(); i++) {
            if (transports.get(i).getTransportID().equals(updated.getTransportID())) {
                transports.set(i, updated);
                break;
            }
        }
        saveTransports(transports);
    }
    
    public static ArrayList<Transport> getAvailableTransports() {
        ArrayList<Transport> all = loadTransports();
        ArrayList<Transport> available = new ArrayList<>();
        for (Transport t : all) {
            if (t.isAvailable()) {
                available.add(t);
            }
        }
        return available;
    }
}