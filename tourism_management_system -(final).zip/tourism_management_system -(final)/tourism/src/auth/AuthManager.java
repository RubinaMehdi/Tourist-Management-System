package auth;

import models.Tourist;
import models.TourGuide;
import utils.FileHandler;
import java.util.*;

public class AuthManager {
    private static AuthManager instance;
    private Map<String, String> touristCredentials;
    private Map<String, String> adminCredentials;
    private Map<String, String> guideCredentials;

    private AuthManager() {
        loadCredentials();
    }

    public static AuthManager getInstance() {
        if (instance == null) {
            instance = new AuthManager();
        }
        return instance;
    }

    private void loadCredentials() {
        touristCredentials = new HashMap<>();
        adminCredentials = new HashMap<>();
        guideCredentials = new HashMap<>();

        ArrayList<Tourist> tourists = FileHandler.loadTourists();
        for (Tourist t : tourists) {
            touristCredentials.put(t.getPersonID(), t.getPassword());
        }

        adminCredentials.put("admin", "admin123");

        ArrayList<TourGuide> guides = FileHandler.loadGuides();
        for (TourGuide g : guides) {
            guideCredentials.put(g.getGuideID(), g.getPassword());
        }
    }

    public String authenticate(String userId, String password, String role) {
        switch (role) {
            case "tourist":
                if (touristCredentials.containsKey(userId) &&
                        touristCredentials.get(userId).equals(password)) {
                    return userId;
                }
                break;
            case "admin":
                if (adminCredentials.containsKey(userId) &&
                        adminCredentials.get(userId).equals(password)) {
                    return userId;
                }
                break;
            case "tour guide":
                if (guideCredentials.containsKey(userId) &&
                        guideCredentials.get(userId).equals(password)) {
                    return userId;
                }
                break;
        }
        return null;
    }

    public void refreshCredentials() {
        loadCredentials();
    }
}
